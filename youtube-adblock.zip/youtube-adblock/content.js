let adBlockEnabled = true;
let userPaused = false;

// Ayar durumu al
chrome.storage.local.get(["enabled"], (data) => {
  adBlockEnabled = data.enabled !== false;
});

// Reklam atlama butonu
function skipAdIfExists() {
  const skipBtn = document.querySelector('.ytp-ad-skip-button');
  if (skipBtn && skipBtn.offsetParent !== null) {
    skipBtn.click();
    chrome.runtime.sendMessage("incrementAdCount");
    return true;
  }
  return false;
}

// Süreye göre hızlı reklam atlama
function fastForwardAd() {
  const video = document.querySelector('video');
  if (video && video.duration < 90 && video.currentTime < video.duration - 1) {
    video.currentTime = video.duration;
    chrome.runtime.sendMessage("incrementAdCount");
    return true;
  }
  return false;
}

// Reklam oynuyor mu kontrol et
function isAdPlaying() {
  const video = document.querySelector('video');
  return document.querySelector('.ad-showing') && video && video.duration < 120;
}


// Kullanıcı video durdurdu mu izle (boşluk tuşu + mouse click)
document.addEventListener('keydown', (e) => {
  if (e.code === 'Space') {
    const video = document.querySelector('video');
    if (video) {
      userPaused = video.paused;
    }
  }
});

document.addEventListener('click', () => {
  const video = document.querySelector('video');
  if (video) {
    userPaused = video.paused;
  }
});

// Ana reklam kontrol döngüsü
function checkForAds() {
  if (!adBlockEnabled) return;

  if (isAdPlaying()) {
    const skipped = skipAdIfExists();
    if (!skipped) {
      fastForwardAd();
    }
  }}

  // Görsel reklam elementlerini temizle
  const adSelectors = [
    '.ytp-ad-module', '.video-ads', '#player-ads',
    '.ytp-ad-player-overlay', '.ytp-ad-text',
    '.ytp-ad-overlay-close-button'
  ];
  adSelectors.forEach(selector => {
    document.querySelectorAll(selector).forEach(el => el.remove());
  });


// Her saniyede bir kontrol et
setInterval(checkForAds, 1000);

// Ayar durumu dinle (devre dışı bırak/aç)
chrome.storage.onChanged.addListener((changes) => {
  if (changes.enabled) {
    adBlockEnabled = changes.enabled.newValue !== false;
  }
});
