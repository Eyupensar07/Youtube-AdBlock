let adBlockEnabled = true;

chrome.storage.local.get(["enabled"], (data) => {
  adBlockEnabled = data.enabled !== false;
});

function skipAdIfExists() {
  const skipBtn = document.querySelector('.ytp-ad-skip-button');
  if (skipBtn && skipBtn.offsetParent !== null) {
    skipBtn.click();
    chrome.runtime.sendMessage("incrementAdCount");
    return true;
  }
  return false;
}

function fastForwardAd() {
  const video = document.querySelector('video');
  if (video && video.duration < 90 && video.currentTime < video.duration - 1) {
    video.currentTime = video.duration;
    chrome.runtime.sendMessage("incrementAdCount");
    return true;
  }
  return false;
}

function isAdPlaying() {
  const video = document.querySelector('video');
  return document.querySelector('.ad-showing') && video && video.duration < 120;
}

function fixBlackScreen() {
  const video = document.querySelector('video');
  const isAdOverlay = document.querySelector('.ad-showing');
  if (!video || isAdOverlay) return;

  if (video.paused && video.currentTime > 0 && video.currentTime < video.duration - 1) {
    video.play().catch(() => {});
  }
}

function checkForAds() {
  if (!adBlockEnabled) return;

  if (isAdPlaying()) {
    if (!skipAdIfExists()) {
      fastForwardAd();
    }
  }

  const adSelectors = [
    '.ytp-ad-module', '.video-ads', '#player-ads',
    '.ytp-ad-player-overlay', '.ytp-ad-text',
    '.ytp-ad-overlay-close-button'
  ];
  adSelectors.forEach(selector => {
    document.querySelectorAll(selector).forEach(el => el.remove());
  });

  fixBlackScreen();
}

setInterval(checkForAds, 1000);

chrome.storage.onChanged.addListener((changes) => {
  if (changes.enabled) {
    adBlockEnabled = changes.enabled.newValue !== false;
  }
});
