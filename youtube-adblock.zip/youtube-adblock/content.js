let customSkipBtn = null;
let adBlockEnabled = true;

chrome.storage.local.get(["enabled"], (data) => {
  adBlockEnabled = data.enabled !== false;
});

function skipAdIfExists() {
  const skipBtn = document.querySelector('.ytp-ad-skip-button');
  if (skipBtn && skipBtn.offsetParent !== null) {
    const clickEvent = new MouseEvent('click', {
      view: window,
      bubbles: true,
      cancelable: true
    });
    skipBtn.dispatchEvent(clickEvent);
    chrome.runtime.sendMessage("incrementAdCount");
    return true;
  }
  return false;
}

function fastForwardAd() {
  const video = document.querySelector('video');
  if (video && video.duration < 90 && video.currentTime < video.duration - 1) {
    video.currentTime = video.duration;
    chrome.runtime.sendMessage("incrementAdCount");
    return true;
  }
  return false;
}

function showCustomSkip() {
  if (!customSkipBtn) {
    customSkipBtn = document.createElement('button');
    customSkipBtn.innerText = '⏩ Reklamı Atla';
    Object.assign(customSkipBtn.style, {
      position: 'fixed',
      bottom: '20px',
      right: '20px',
      padding: '10px 15px',
      fontSize: '16px',
      zIndex: 9999,
      background: '#e74c3c',
      color: '#fff',
      border: 'none',
      borderRadius: '5px',
      cursor: 'pointer',
      boxShadow: '0 2px 6px rgba(0,0,0,0.3)'
    });

    customSkipBtn.onclick = () => {
      skipAdIfExists() || fastForwardAd();
      removeCustomSkip();
    };

    document.body.appendChild(customSkipBtn);
  }
}

function removeCustomSkip() {
  if (customSkipBtn && customSkipBtn.remove) {
    customSkipBtn.remove();
    customSkipBtn = null;
  }
}

function isAdPlaying() {
  const video = document.querySelector('video');
  return document.querySelector('.ad-showing') && video && video.duration < 120;
}

let userPaused = false;

// Siyah ekranda Sayaç Sıfırla butonu işlevi
function fixBlackScreen() {
  const video = document.querySelector('video');
  const isAdOverlay = document.querySelector('.ad-showing');

  if (!video || isAdOverlay) return;

  if (video.paused && !userPaused && video.currentTime > 0 && video.currentTime < video.duration - 1) {
    showCustomButton("Sayaç Sıfırla", () => {
      chrome.runtime.sendMessage("resetAdCount");
      location.reload();
    });
  }
}


document.addEventListener('keydown', (e) => {
  if (e.code === 'Space') {
    const video = document.querySelector('video');
    if (video) {
      userPaused = video.paused;
    }
  }
});

document.addEventListener('click', () => {
  const video = document.querySelector('video');
  if (video) {
    userPaused = video.paused;
  }
});

function checkForAds() {
  if (!adBlockEnabled) return;

  if (isAdPlaying()) {
    if (!skipAdIfExists()) {
      fastForwardAd();
      showCustomSkip();
    } else {
      removeCustomSkip();
    }
  } else {
    removeCustomSkip();
  }

  const adSelectors = [
    '.ytp-ad-module', '.video-ads', '#player-ads',
    '.ytp-ad-player-overlay', '.ytp-ad-text',
    '.ytp-ad-overlay-close-button'
  ];
  adSelectors.forEach(selector => {
    document.querySelectorAll(selector).forEach(el => el.remove());
  });

  fixBlackScreen();
}

setInterval(checkForAds, 1000);

// Dinamik olarak ayarı izleyelim:
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes.enabled) {
    adBlockEnabled = changes.enabled.newValue !== false;
    console.log("AdBlock durumu güncellendi:", adBlockEnabled);
  }
});
