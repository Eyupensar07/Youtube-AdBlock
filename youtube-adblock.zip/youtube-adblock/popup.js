const statusDiv = document.getElementById('status');
const toggleBtn = document.getElementById('toggleBtn');
const adCountDiv = document.getElementById('adCount');
const resetCounterBtn = document.getElementById('resetCounterBtn');
const langSelect = document.getElementById('langSelect');
const title = document.getElementById('title');

const translations = {
  en: {
    title: "YouTube AdBlock",
    status_on: "Status: Active",
    status_off: "Status: Disabled",
    enable: "Enable",
    disable: "Disable",
    ads_blocked: "Ads blocked",
    reset: "Reset Counter"
  },
  tr: {
    title: "YouTube Reklam Engelleyici",
    status_on: "Durum: Aktif",
    status_off: "Durum: Devre Dışı",
    enable: "Etkinleştir",
    disable: "Devre Dışı Bırak",
    ads_blocked: "Engellenen reklam",
    reset: "Sayacı Sıfırla"
  }
};

let currentLang = 'en';

function applyLang() {
  const t = translations[currentLang];
  chrome.storage.local.get(['enabled', 'adCount'], (data) => {
    const enabled = data.enabled !== false;
    const adCount = data.adCount || 0;

    title.textContent = t.title;
    statusDiv.textContent = enabled ? t.status_on : t.status_off;
    toggleBtn.textContent = enabled ? t.disable : t.enable;
    adCountDiv.textContent = `${t.ads_blocked}: ${adCount}`;
    resetCounterBtn.textContent = t.reset;
  });
}

langSelect.addEventListener('change', () => {
  currentLang = langSelect.value;
  chrome.storage.local.set({ lang: currentLang }, applyLang);
});

toggleBtn.addEventListener('click', () => {
  chrome.storage.local.get('enabled', (data) => {
    const newState = !(data.enabled !== false);
    chrome.storage.local.set({ enabled: newState }, applyLang);
  });
});

resetCounterBtn.addEventListener('click', () => {
  chrome.runtime.sendMessage("resetAdCount");
  chrome.storage.local.set({ adCount: 0 }, applyLang);
});

chrome.storage.local.get(['lang'], (data) => {
  currentLang = data.lang || 'en';
  langSelect.value = currentLang;
  applyLang();
});

chrome.storage.onChanged.addListener((changes) => {
  if (changes.adCount) {
    applyLang();
  }
});
