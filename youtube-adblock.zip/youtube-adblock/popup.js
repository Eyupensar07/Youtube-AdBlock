const toggleBtn = document.getElementById('toggleBtn');
const statusDiv = document.getElementById('status');
const adCountDiv = document.getElementById('adCount');
const resetCounterBtn = document.getElementById('resetCounterBtn');

const getMessage = (key) => chrome.i18n.getMessage(key);

function updateUI(enabled, adCount) {
  if (enabled !== null) {
    statusDiv.textContent = enabled ? getMessage("status_active") : getMessage("status_inactive");
    toggleBtn.textContent = enabled ? getMessage("toggle_on") : getMessage("toggle_off");
  }
  if (adCount !== null) {
    adCountDiv.textContent = getMessage("ad_count_label").replace("$COUNT$", adCount);
  }
  resetCounterBtn.textContent = getMessage("reset_counter");
}

chrome.storage.local.get(['enabled', 'adCount'], data => {
  updateUI(data.enabled !== false, data.adCount || 0);
});

toggleBtn.addEventListener('click', () => {
  chrome.storage.local.get('enabled', data => {
    const current = data.enabled !== false;
    chrome.storage.local.set({ enabled: !current }, () => {
      chrome.storage.local.get('adCount', d => {
        updateUI(!current, d.adCount || 0);
      });
    });
  });
});

resetCounterBtn.addEventListener('click', () => {
  chrome.runtime.sendMessage("resetAdCount");
  chrome.storage.local.set({ adCount: 0 }, () => {
    updateUI(null, 0);
  });
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local") {
    if (changes.enabled) {
      chrome.storage.local.get('adCount', d => {
        updateUI(changes.enabled.newValue !== false, d.adCount || 0);
      });
    }
    if (changes.adCount) {
      chrome.storage.local.get('enabled', d => {
        updateUI(d.enabled !== false, changes.adCount.newValue);
      });
    }
  }
});
const languageSelector = document.getElementById("languageSelector");

chrome.storage.local.get("selectedLanguage", data => {
  const lang = data.selectedLanguage || "tr";
  languageSelector.value = lang;
  setLocale(lang); // Sayfayı o dilde çiz
});

languageSelector.addEventListener("change", () => {
  const selected = languageSelector.value;
  chrome.storage.local.set({ selectedLanguage: selected }, () => {
    setLocale(selected);
  });
});

function setLocale(lang) {
  const messages = locales[lang] || locales["tr"];
  statusDiv.textContent = messages.status_active;
  toggleBtn.textContent = messages.toggle_on;
  adCountDiv.textContent = messages.ad_count_label.replace("$COUNT$", "0"); // Başlangıçta 0
  resetCounterBtn.textContent = messages.reset_counter;
}

// Basit yerel sözlük objesi
const locales = {
  tr: {
    status_active: "Durum: Aktif",
    status_inactive: "Durum: Devre Dışı",
    toggle_on: "Devre Dışı Bırak",
    toggle_off: "Aktif Et",
    ad_count_label: "Engellenen reklam: $COUNT$",
    reset_counter: "Sayaç Sıfırla"
  },
  en: {
    status_active: "Status: Active",
    status_inactive: "Status: Disabled",
    toggle_on: "Disable",
    toggle_off: "Enable",
    ad_count_label: "Ads blocked: $COUNT$",
    reset_counter: "Reset Counter"
  }
};
