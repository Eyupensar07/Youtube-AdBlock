const toggleBtn = document.getElementById('toggleBtn');
const statusDiv = document.getElementById('status');
const adCountDiv = document.getElementById('adCount');
const resetCounterBtn = document.getElementById('resetCounterBtn');
const languageSelector = document.getElementById('languageSelector');

const locales = {
  tr: {
    status_active: "Durum: Aktif",
    status_inactive: "Durum: Devre Dışı",
    toggle_on: "Devre Dışı Bırak",
    toggle_off: "Aktif Et",
    ad_count_label: "Engellenen reklam: $COUNT$",
    reset_counter: "Sayaç Sıfırla"
  },
  en: {
    status_active: "Status: Active",
    status_inactive: "Status: Disabled",
    toggle_on: "Disable",
    toggle_off: "Enable",
    ad_count_label: "Ads blocked: $COUNT$",
    reset_counter: "Reset Counter"
  }
};

let currentLanguage = "tr";

function updateUI(enabled, adCount) {
  const messages = locales[currentLanguage];

  if (enabled !== undefined && enabled !== null) {
    statusDiv.textContent = enabled ? messages.status_active : messages.status_inactive;
    toggleBtn.textContent = enabled ? messages.toggle_on : messages.toggle_off;
  }
  if (adCount !== undefined && adCount !== null) {
    adCountDiv.textContent = messages.ad_count_label.replace("$COUNT$", adCount);
  }
  resetCounterBtn.textContent = messages.reset_counter;
}

function setLocale(lang) {
  currentLanguage = lang;
  chrome.storage.local.set({ selectedLanguage: lang });
  chrome.storage.local.get(['enabled', 'adCount'], data => {
    updateUI(data.enabled !== false, data.adCount || 0);
  });
}

chrome.storage.local.get(['selectedLanguage', 'enabled', 'adCount'], data => {
  currentLanguage = data.selectedLanguage || "tr";
  languageSelector.value = currentLanguage;
  updateUI(data.enabled !== false, data.adCount || 0);
});

toggleBtn.addEventListener('click', () => {
  chrome.storage.local.get('enabled', data => {
    const current = data.enabled !== false;
    chrome.storage.local.set({ enabled: !current }, () => {
      chrome.storage.local.get('adCount', d => {
        updateUI(!current, d.adCount || 0);
      });
    });
  });
});

resetCounterBtn.addEventListener('click', () => {
  // Sadece sayaç sıfırlanıyor, aktiflik durumu değişmiyor
  chrome.runtime.sendMessage("resetAdCount");
  chrome.storage.local.set({ adCount: 0 }, () => {
    updateUI(null, 0); // enabled null, değişmeden kalır
  });
});

languageSelector.addEventListener('change', () => {
  setLocale(languageSelector.value);
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local") {
    if (changes.enabled) {
      chrome.storage.local.get('adCount', d => {
        updateUI(changes.enabled.newValue !== false, d.adCount || 0);
      });
    }
    if (changes.adCount) {
      chrome.storage.local.get('enabled', d => {
        updateUI(d.enabled !== false, changes.adCount.newValue);
      });
    }
    if (changes.selectedLanguage) {
      currentLanguage = changes.selectedLanguage.newValue || "tr";
      updateUI(null, null);
    }
  }
});
