let adCount = 0;

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message === "incrementAdCount") {
    adCount++;
    chrome.storage.local.set({ adCount });
    sendResponse({ success: true });
  } else if (message === "resetAdCount") {
    adCount = 0;
    chrome.storage.local.set({ adCount });
    sendResponse({ success: true });
  }
});
