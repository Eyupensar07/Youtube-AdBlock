chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message === "incrementAdCount") {
    chrome.storage.local.get(["adCount"], (data) => {
      const newCount = (data.adCount || 0) + 1;
      chrome.storage.local.set({ adCount: newCount });
    });
  } else if (message === "resetAdCount") {
    chrome.storage.local.set({ adCount: 0 });
  }
});
